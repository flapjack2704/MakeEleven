package main.java;

/*

 */
public class Opponent {
    public Card getOpponentCard() {
        return opponentCard;
    }

    public void setOpponentCard(Card opponentCard) {
        this.opponentCard = opponentCard;
    }

    private Card opponentCard = new Card();


}
